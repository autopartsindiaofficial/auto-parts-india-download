AUTOPARTS INDIA — BLUE / LIGHT WEBSITE
- No dark background.
- Orange has been removed; primary branding/UI uses blue.
- Main website is English with only small Hindi touches.
- Hindi CTA included exactly in meaning:
  "डीलर के रूप में Total Loss वाहन अभी डाउनलोड करें"
- Uses the three supplied vehicle images.
- Support: autopartsindia7@gmail.com
- APK button expects: autoparts-india.apk
